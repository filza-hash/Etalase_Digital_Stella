<?php
// Koneksi ke Basis Data (PDO MySQL)
// Sesuaikan dengan pengaturan MySQL kamu (XAMPP default: root tanpa password)
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'etalase_stella');
define('DB_USER', 'root');
define('DB_PASS', '');

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}
